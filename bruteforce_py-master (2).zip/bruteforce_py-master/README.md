bruteforce_py
=============

All codes in this repo are not mine, last time I used this code for playing <br/>
all bruteforce with python, ssh bf, wordpress bf, cpanel bf, mysql bf, etc</br>

You can fork, download, and using this code. 

Thank you, :) 
