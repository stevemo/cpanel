rm -f cloudflare_simple.tar.bz2
tar -jcvf cloudflare_simple.tar.bz2 cloudflare_simple/*

