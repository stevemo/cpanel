## CHANGELOG

2.0.0 (Work in progress)
-----

- [add] You can now configure the url prefix to access the Cpanel
- [mod] Upgrade JQuery plugin Select2 to version 3.4.5
- [mod] All routes are now prefix cpanel instead of admin