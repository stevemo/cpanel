<?php

return array(
    'logout'                     => 'Logout war erfolgreich.',
    'register_success'           => 'Gratulation! Die Registrierung war erfolgreich.',
    'create_success'             => 'Benutzer angelegt.',
    'update_success'             => 'Benutzer bearbeitet.',
    'login_success'              => 'Sie sind erfolgreich angemeldet.',
    'delete_denied'              => 'Achtung: Sie können sich nicht selber löschen.',
    'delete_success'             => 'Benutzer gelöscht.',
    'permissions_update_success' => 'Benutzer Rechte bearbeitet.',
    'activation_success'         => 'Benutzer erfolgreich aktiviert.',
    'activation_fail'            => 'Benutzer Aktivierung misslungen.',
    'deactivation_success'       => 'Benutzer erfolgreich aktiviert.',
    'password_reset_success'     => 'Passwort erfolgreich zurückgesetzt',
);
