<?php

return array(
	'success'          => 'Dieser Benutzer ist nun :action',
    'action_not_found' => 'Folgende Aktion ist nicht verfügbar: [:action]'
);