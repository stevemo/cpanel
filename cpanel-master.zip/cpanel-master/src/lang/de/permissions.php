<?php

return array(
   'no_found'        => 'Keine Rechte für diese Gruppe gefunden.',
   'create_success'  => 'Rechte erfolgreich erstellt.',
   'model_not_found' => 'Diese Rechte existieren nicht.',
   'update_success'  => 'Rechte verändert.',
   'delete_success'  => 'Modul Rechte gelöst.',
   'no_permission'   => 'Keine Rechte gefunden.',
   'access_denied'   => 'Sie besitzen keine Rechte für diese Seite.',
);
