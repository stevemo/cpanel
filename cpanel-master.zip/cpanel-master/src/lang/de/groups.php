<?php

return array(
    'no_group'       => 'Gruppe nicht gefunden.',
    'create_success' => 'Neue Gruppe erstellt.',
    'delete_success' => 'Gruppe entfernt.',
    'update_success' => 'Gruppe verändert.',
);  
