<?php

return array(
    'no_group'       => 'Nie znaleziono grup.',
    'create_success' => 'Nowa grupa utworzona.',
    'delete_success' => 'Grupa usunięta.',
    'update_success' => 'Grupa zaktualizowana.',
);  
