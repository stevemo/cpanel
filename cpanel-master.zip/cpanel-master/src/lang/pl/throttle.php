<?php

return array(

    'success'          => 'Ten użytkownik jest teraz :action',
    'action_not_found' => 'Ta akcja nie jest możliwa [:action]'
);