<?php

return array(
   'no_found'        => 'Nie znaleziono modułu uprawnień.',
   'create_success'  => 'Uprawnienia utworzone.',
   'model_not_found' => 'Te uprawnienia nie istnieją.',
   'update_success'  => 'Uprawnienia zaktualizowane.',
   'delete_success'  => 'Moduł uprawnień usunięty.',
   'no_permission'   => 'Nie znaleziono uprawnień.',
   'access_denied'   => 'Nie masz wystarczających uprawnień żeby wyświetlać tą stronę.',
);
