<?php

return array(
    'no_group'       => 'No Groups found.',
    'create_success' => 'New group created.',
    'delete_success' => 'Group deleted.',
    'update_success' => 'Group updated.',
);  
