<?php

return array(

    'success'          => 'This user is now :action',
    'action_not_found' => 'This action is not available [:action]'
);