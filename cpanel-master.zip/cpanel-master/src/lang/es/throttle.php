<?php

return array(
	'success'          => 'El usuario está :action',
    'action_not_found' => 'La acción no está disponible [:action]'
);