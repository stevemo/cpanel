<?php

return array(
   'no_found'        => 'No se han encontrado permisos para el módulo.',
   'create_success'  => 'Permisos creados.',
   'model_not_found' => 'Los permisos no existen.',
   'update_success'  => 'Permisos modificados.',
   'delete_success'  => 'Borrados permisos del módulo.',
   'no_permission'   => 'No se han encontrado permisos.',
   'access_denied'   => 'Permisos insuficientes para acceder a la página.',
);
