<?php

return array(
    'no_group'       => 'No se han encontrado grupos.',
    'create_success' => 'Nuevo grupo creado.',
    'delete_success' => 'Grupo borrado.',
    'update_success' => 'Grupo modificado.',
);  
