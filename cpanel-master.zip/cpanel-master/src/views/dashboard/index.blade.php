@extends(Config::get('cpanel::views.layout'))

@section('header')
    <h3>
        <i class="icon-dashboard"></i>
        Dashboard
    </h3>
@stop
