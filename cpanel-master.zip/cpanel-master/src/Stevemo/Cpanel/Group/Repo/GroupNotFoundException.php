<?php namespace Stevemo\Cpanel\Group\Repo;

class GroupNotFoundException extends \UnexpectedValueException {}