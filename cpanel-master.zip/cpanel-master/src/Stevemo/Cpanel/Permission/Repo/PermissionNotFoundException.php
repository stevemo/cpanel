<?php  namespace Stevemo\Cpanel\Permission\Repo; 

class PermissionNotFoundException extends \Exception {}