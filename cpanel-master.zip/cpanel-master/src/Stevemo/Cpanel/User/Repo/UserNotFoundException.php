<?php  namespace Stevemo\Cpanel\User\Repo; 

class UserNotFoundException extends \OutOfBoundsException {}